﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace billardooo_2_lol
{
    internal class Ball
    {

        double r = 30;
        public double x;
        public double y;
        public double vx;
        public double vy;
        double drag = 0.01;
        int table_height;
        int table_width;
        int ball_click;
        Brush brush;
        private int height;
        private int width;
        private int v1;
        private int v2;
        private int v3;
        private int v4;

        public Ball(int table_height , int table_width, double x, double y , double vx, double vy, SolidBrush brush)
        {
            this.table_height = table_height;
            this.table_width = table_width;
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.brush = brush;
   

        }

        public Ball(int height, int width, int v1, int v2, int v3, int v4)
        {
            this.height = height;
            this.width = width;
            this.v1 = v1;
            this.v2 = v2;
            this.v3 = v3;
            this.v4 = v4;
        }

        public void roll()
        {
            x += vx;
            y += vy;

           if (vx > 0 )
            {
                vx -= drag * vx;
            }

            if (vy > 0)
            {
                vy -= drag * vy;
            }

            if (vx < 0)
            {
                vx -= drag * vx;
            }

            if (vy < 0)
            {
                vy -= drag * vy;
            }


        }

        public void table_check()
        {
            if (x <= r || (int)x >= table_width - (int)r )
            {
                vx = vx * (-1);
            }
            if (y <= r || (int)y >= table_height - (int)r)
            {
                vy = vy * (-1);
            }


        }

       
        public void ball_bounce_check()
        {
            table_check();
        }

        public void ball_click_check()
        {
            ball_click = 1;
            
        }
        
        public void ball_click_two(int click2x,int click2y)
        {
            vx += (x-click2x)/10+drag*vy;
            vy += (y-click2y)/10+drag*vx;
            ball_click = 0;
        }

        public void ball_hit(double newvx , double newvy )
        {
            vx = newvx;
            vy = newvy;
        }

        public int ballx()
        {
            return (int)x;
        }
        public int bally()
        {
            return (int)y;
        }
 
        public int click_one()
        {
            return ball_click;
        }
        public void Draw(Graphics g)
        {

            if (ball_click == 1)
            {
                Brush brush1 = new SolidBrush(Color.OrangeRed);
                g.FillEllipse(brush1, (int)x, (int)y, (int)r, (int)r);

            }
            else
            {
                g.FillEllipse(brush, (int)x, (int)y, (int)r, (int)r);
            }
        }

    }
}
