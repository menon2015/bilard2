﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace billardooo_2_lol
{
    public partial class Form1 : Form
    {
        
        List<Ball> BallList = new List<Ball>();
        List<Hole> HoleList = new List<Hole>();


        public Form1()
        {
            InitializeComponent();

            Random r = new Random();
            for (int i = 1; i < 10; i++)

            {

                int red = r.Next(0, byte.MaxValue + 1);
                int green = r.Next(0, byte.MaxValue + 1);
                int blue = r.Next(0, byte.MaxValue + 1);
                SolidBrush brush = new System.Drawing.SolidBrush(Color.FromArgb(red, green, blue));
                BallList.Add(new Ball(pictureBox1.Height, pictureBox1.Width, (100 * i), (pictureBox1.Height / 2) - 15, 0, 0,brush));
            }
            HoleList.Add(new Hole(-50,-50));
            HoleList.Add(new Hole(-50, pictureBox1.Height-50));
            HoleList.Add(new Hole(pictureBox1.Width-50, -50));
            HoleList.Add(new Hole(pictureBox1.Width-50, pictureBox1.Height-50));
            HoleList.Add(new Hole((pictureBox1.Width/2)-50, -50));
            HoleList.Add(new Hole((pictureBox1.Width/2)-50, pictureBox1.Height-50));




        }



        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            
           
        }

        
            private List<int> Swapv(int vx1,int vy1,int vx2,int vy2)
        {


            return new List<int> { vx1, vy1, vx2, vy2 };
        }



        private bool Colide(Ball ball1,Ball ball2)
        {
            double distx=ball1.ballx()-ball2.ballx();
            double disty= ball1.bally() - ball2.bally();
            if (Math.Sqrt((distx*distx)+(disty*disty))<30)
            {
                return true;
            }
            return false;

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int j = 0; j < BallList.Count; j++)
            {
                for (int i = j+1; i < BallList.Count; i++)
                {
                    if (j != i && Colide(BallList[i], BallList[j]))
                    {
                        List<int> VList = Swapv((int)BallList[j].vx, (int)BallList[j].vy, (int)BallList[i].vx, (int)BallList[i].vy);


                        BallList[i].ball_hit(VList[0], VList[1]);
                        BallList[j].ball_hit(VList[2], VList[3]);


                    }
                  
                }
            }
   
            foreach (var ball in BallList)
            {
             
                
                ball.ball_bounce_check();
                ball.roll();
            }
            pictureBox1.Invalidate();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {

            Graphics g = e.Graphics;
            foreach(var ball in BallList)
            {
                ball.Draw(g);
            }
            
            foreach(var hole in HoleList)
            {
                hole.Draw(g);
            }
        


        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int clicky = e.Y;
            int clickx = e.X;
            foreach (var ball in BallList)
            {
                if (ball.click_one() == 0)
                {
                    if (clickx >= ball.ballx() - 30 & clickx <= ball.ballx() + 30 & clicky <= ball.bally() + 30 & clicky >= ball.bally() - 30)
                    {
                        ball.ball_click_check();

                    }
                }
                else
                {
                    ball.ball_click_two(clickx, clicky);
                }
            }

            


        }
    }
}
