﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace billardooo_2_lol
{
    internal class Hole
    {
        private int x;
        private int y;
        private int r = 100;
        public Hole(int x , int y)
        {
            this.x = x;
            this.y = y;

        }

        public void Draw(Graphics g)
        {
            Brush brush = new SolidBrush(Color.Black);
            g.FillEllipse(brush, (int)x, (int)y, (int)r, (int)r);
        }
    }

}
